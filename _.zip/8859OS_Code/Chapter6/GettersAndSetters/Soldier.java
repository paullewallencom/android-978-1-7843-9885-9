package com.packtpub.gettersandsetters.app;

/**
 * Created by John on 31/07/2014.
 */
public class Soldier{
    private int health;
    public int getHealth(){
        return health;
    }

    public void setHealth(int newHealth){
        health = newHealth;
    }
}

